<?php
/*function getParams()
{
    $segments = explode('/', $_SERVER['PATH_INFO']);
    $params = array();
    for ($s = 1; $s < sizeof($segments); $s = $s + 2) {
        if ($segments[$s] == '') break;
        $params[$segments[$s]] = $segments[$s + 1];
    }
    return $params;
}*/

function getDB()
{
    global $config;

    $db = mysqli_connect($config['hostname'], $config['username'], $config['password'], $config['database']);

    if (!$db) {
        echo "Error: Unable to connect to MySQL." . PHP_EOL;
        echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
        echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
        exit;
    }
    return $db;
}

function getRows($result)
{
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function getRow($result)
{
    $rows = getRows($result);
    return sizeof($rows) ? $rows[0] : NULL;
}


function getTableData($table, $conditions = NULL)
{
    $db = getDB();

    $mode = isset($conditions['mode']) ? $conditions['mode'] : "json";
    $primary = isset($conditions['primary']) ? $conditions['primary'] : "id";

    $count = isset($conditions['count']) ? $conditions['count'] : false;
    $where = isset($conditions['where']) ? $conditions['where'] : "";
    $order = isset($conditions['order']) ? $conditions['order'] : "";
    $limit = isset($conditions['limit']) ? $conditions['limit'] : NULL;
    $offset = isset($conditions['offset']) ? $conditions['offset'] : "";
    $fields = isset($conditions['fields']) ? $conditions['fields'] : "*";

    $query = "SELECT ";
    $query .= $count ? "COUNT(*) AS total_rows" : $fields;
    $query .= " FROM `".$table."`";
    if ($where != "") $query .= " WHERE " . $where;
    if ($order != "") $query .= " ORDER BY " . $order;
    
    if (!is_null($limit)) {
        $query .= " LIMIT " . $limit;
        if ($offset != "") $query .= "," . $offset;
    }

    $rows = mysqli_query($db, $query) or die (mysqli_error($db));   // getting data from table.

    if ($count) {      // for getting counts of total rows.
        $result = getRow($rows);
    } else {    // default flow. 
        $result = getRows($rows);
    }
    
    if ($mode == "json") {
        $resultTemp = array();
        if (sizeof($result)) {
            foreach ($result as $key => $value) {
                if (array_key_exists($primary, $value)) {
                    $resultTemp[$value[$primary]] = $value;
                } else {
                    exit('set the primary key into $conditions');
                }
            }
        }
        $result = $resultTemp;
    }
    mysqli_close($db);

    return $result;
}

function insertRow ($table, $data) {
    $db = getDB();

    $fields = "";
    $values = "";
    if (sizeof($data)) {
        foreach ($data as $key => $value) {
            $fields .= ",`" . $key . "`";
            $values .= ",'".$value."'";
        }
    }

    $result = mysqli_query($db, "INSERT INTO `".$table."` (`id`".$fields.") VALUES (NULL".$values.");") or die (mysqli_error($db));
    mysqli_close($db);
}


function updateRow ($table, $data, $id) {
    $db = getDB();

    $fields = "";
    if (sizeof($data)) {
        foreach ($data as $key => $value) {
            $fields .= ",`".$key."` = '".$value."'";
        }
    }
    $fields = substr($fields, 1); // deleting comma at first.
    $sql = mysqli_query($db, "UPDATE `".$table."` SET ".$fields." WHERE `".$table."`.`id` = ".$id.";") or die (mysqli_error($db));
    mysqli_close($db);
    return 'OK';
}


function deleteRow ($table, $id) {
    $db = getDB();

    $sql = mysqli_query($db, "DELETE FROM `".$table."` WHERE `".$table."`.`id` = ".$id.";") or die (mysqli_error($db));
    mysqli_close($db);
    return 'OK';
}



//---------------------------------------------------------------------------------------




function getSatellites()
{
    $db = getDB();
    $result = mysqli_query($db, "
            SELECT * FROM `satellites` 
            ORDER BY id  
        ") or die (mysqli_error($db));
    mysqli_close($db);
    return getRows($result);
}

function addSatellite($data)
{
    $db = getDB();
    $result = mysqli_query($db, "
        INSERT INTO `satellites` (`id`, `sate_name`, `orbit`, `url`, `beams`, `company`, `country`, `launch_date`, `life_time`, `status`, `footprint`, `website`, `note`) 
        VALUES (NULL, 
            '".$data['sate_name']."', 
            '".$data['orbit']."', 
            '".$data['url']."', 
            '".$data['beams']."', 
            '".$data['company']."', 
            '".$data['country']."', 
            '".$data['launch_date']."', 
            '".$data['life_time']."', 
            '".$data['status']."', 
            '".$data['footprint']."', 
            '".$data['website']."', 
            '".$data['note']."'
        );
    ") or die (mysqli_error($db));
    mysqli_close($db);
    return 'OK';
}
function updateSatellite($id, $data)
{
    $db = getDB();
    $result = mysqli_query($db, "
        UPDATE `satellites` 
        SET `sate_name` = '".$data['sate_name']."',
            `orbit` = '".$data['orbit']."',
            `url` = '".$data['url']."',
            `beams` = '".$data['beams']."',
            `company` = '".$data['company']."',
            `country` = '".$data['country']."',
            `launch_date` = '".$data['launch_date']."',
            `life_time` = '".$data['life_time']."',
            `status` = '".$data['status']."',
            `footprint` = '".$data['footprint']."',
            `website` = '".$data['website']."',
            `note` = '".$data['note']."'
        WHERE `satellites`.`id` = ".$id.";
    ") or die (mysqli_error($db));
    mysqli_close($db);
    return 'OK';
}
function deleteTableData($id)
{
    $db = getDB();
    $result = mysqli_query($db, "DELETE FROM `tbl_data` WHERE `id`='".$id."';") or die (mysqli_error($db));
    mysqli_close($db);
    return 'OK';
}

function getHomePageData () {
    $db = getDB();
    $result = mysqli_query($db, "
            SELECT * FROM `tbl_data` 
            ORDER BY id DESC 
            LIMIT 0, 10 
        ") or die (mysqli_error($db));
    mysqli_close($db);
    return getRows($result);
}