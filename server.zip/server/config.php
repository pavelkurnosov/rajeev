<?php 
	$config = array(
		'hostname' => 'localhost', 
		'username' => 'root', 
		'password' => '',
		'database' => 'flysat_db', 
	);