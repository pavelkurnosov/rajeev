<?php

header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Origin: *');

require_once('config.php');
require_once('functions.php');

if (!isset($_REQUEST['flag'])) $_REQUEST['flag'] = '';
$snippets = explode('-', $_REQUEST['flag']);
$page = $snippets[0];
if (isset($snippets[1])) {
    $mode = $snippets[1];
}

$itemsPerPage = 15;

switch ($page) {
    case 'getsatecombo':
        echo json_encode(getTableData('satellites', array('fields'=>'id,sate_name')));
        exit;

    case 'get_home_data':
        $data = getHomePageData();
        exit(json_encode($data));

    case 'get_hotbird_data':
        $data = getHotbirdData();
        exit(json_encode($data));
    
    case 'beam':
        $table = 'beams';
        switch ($mode) {
            case 'delete':
                deleteRow($table, $_REQUEST['id']);
                break;

            case 'save':
                $fields = array('beam_name', 'link', 'sate_id');

                $clientData = json_decode(file_get_contents("php://input"));
            
                $data = array();
                foreach ($fields as $field) {
                  $data[$field] = isset($clientData->$field) ? $clientData->$field : '';
                }

                isset($_REQUEST['id']) ? updateRow($table, $data, $_REQUEST['id']) : insertRow($table, $data);
                break;

            default:
        }
        exit;

    case 'satellites':
        $table = 'satellites';
        switch ($mode) {
            case 'get':
                $result = getTableData($table, array(
                    'limit'  => ($_REQUEST['p'] - 1) * $itemsPerPage, 
                    'offset' => $itemsPerPage
                ));

                if (sizeof($result)) {
                    foreach ($result as $key => $value) {
                        $beams = getTableData('beams', array('where'=>"sate_id='".$key."'"));
                        $result[$key]['beams'] = $beams;
                    }
                }

                echo json_encode($result);
                break;

            case 'getcount':
                echo json_encode(getTableData($table, array('count' => true)));
                break;

            case 'delete':
                deleteRow($table, $_REQUEST['id']);
                break;

            case 'save':
                $fields = array('sate_name', 'orbit', 'url_name', 'company', 'country', 'launch_date', 'life_time', 'status', 'footprint', 'website', 'note');

                $clientData = json_decode(file_get_contents("php://input"));
            
                $data = array();
                foreach ($fields as $field) {
                  $data[$field] = isset($clientData->$field) ? $clientData->$field : '';
                }

                isset($_REQUEST['id']) ? updateRow($table, $data, $_REQUEST['id']) : insertRow($table, $data);
                break;

            default:
        }
        exit;

    case 'frequencies':
        $table = 'frequencies';
        switch ($mode) {
            case 'get':
                $satellites = getTableData('satellites', array('fields'=>'id,sate_name'));

                $result = getTableData($table, array('limit'  => ($_REQUEST['p'] - 1) * $itemsPerPage, 'offset' => $itemsPerPage));

                if (sizeof($result)) {
                    foreach ($result as $key => $value) {
                        $result[$key]['sate_name'] = $satellites[$value['satellite']]['sate_name'];
                    }
                }

                echo json_encode($result);
                break;

            case 'getcount':
                echo json_encode(getTableData($table, array('count' => true)));
                break;

            case 'delete':
                deleteRow($table, $_REQUEST['id']);
                break;

            case 'save':
                $fields = array('satellite','band','tp','frequency','symbol_rate','fec','modulation','provider','polarization','fformat','status','date_added','note');

                $clientData = json_decode(file_get_contents("php://input"));
            
                $data = array();
                foreach ($fields as $field) {
                  $data[$field] = isset($clientData->$field) ? $clientData->$field : '';
                }

                isset($_REQUEST['id']) ? updateRow($table, $data, $_REQUEST['id']) : insertRow($table, $data);
                break;

            default:
        }
        exit;

    case 'channels':
        $table = 'channels';
        switch ($mode) {
            case 'get':
                $satellites = getTableData('satellites', array('fields'=>'id,sate_name'));

                $result = getTableData($table, array('limit'  => ($_REQUEST['p'] - 1) * $itemsPerPage, 'offset' => $itemsPerPage));

                if (sizeof($result)) {
                    foreach ($result as $key => $value) {
                        $result[$key]['sate_name'] = $satellites[$value['satellite']]['sate_name'];
                    }
                }

                echo json_encode($result);
                break;

            case 'getcount':
                echo json_encode(getTableData($table, array('count' => true)));
                break;

            case 'delete':
                deleteRow($table, $_REQUEST['id']);
                break;

            case 'save':
                $fields = array('satellite', 'frequency', 'package', 'channel_name', 'channel_type', 'a_pid_lang', 'main_lang', 'v_pid', 'sid', 'audio_codec', 'video_codec', 'encryption', 'cformat', 'resolution', 'country', 'website', 'infopage', 'status', 'year_launched', 'date_added', 'note');

                $clientData = json_decode(file_get_contents("php://input"));
            
                $data = array();
                foreach ($fields as $field) {
                  $data[$field] = isset($clientData->$field) ? $clientData->$field : '';
                }

                isset($_REQUEST['id']) ? updateRow($table, $data, $_REQUEST['id']) : insertRow($table, $data);
                break;

            default:
        }
        exit;

    case 'packages':
        $table = 'packages';
        switch ($mode) {
            case 'get':
                echo json_encode(getTableData($table, array(
                    'limit'  => ($_REQUEST['p'] - 1) * $itemsPerPage, 
                    'offset' => $itemsPerPage
                )));
                break;

            case 'getcount':
                echo json_encode(getTableData($table, array('count' => true)));
                break;

            case 'delete':
                deleteRow($table, $_REQUEST['id']);
                break;

            case 'save':
                $fields = array('package_name', 'company', 'website', 'languages', 'countries', 'encryptions', 'satellites');

                $clientData = json_decode(file_get_contents("php://input"));
            
                $data = array();
                foreach ($fields as $field) {
                  $data[$field] = isset($clientData->$field) ? $clientData->$field : '';
                }

                isset($_REQUEST['id']) ? updateRow($table, $data, $_REQUEST['id']) : insertRow($table, $data);
                break;

            default:
        }
        exit;

    case 'infopages':
        $table = 'infopages';
        switch ($mode) {
            case 'get':
                echo json_encode(getTableData($table, array(
                    'limit'  => ($_REQUEST['p'] - 1) * $itemsPerPage, 
                    'offset' => $itemsPerPage
                )));
                break;

            case 'getcount':
                echo json_encode(getTableData($table, array('count' => true)));
                break;

            case 'delete':
                deleteRow($table, $_REQUEST['id']);
                break;

            case 'save':
                $fields = array('company', 'url');

                $clientData = json_decode(file_get_contents("php://input"));
            
                $data = array();
                foreach ($fields as $field) {
                  $data[$field] = isset($clientData->$field) ? $clientData->$field : '';
                }

                isset($_REQUEST['id']) ? updateRow($table, $data, $_REQUEST['id']) : insertRow($table, $data);
                break;

            default:
        }
        exit;
        
    default:
}




echo 'Bad request !!!!';